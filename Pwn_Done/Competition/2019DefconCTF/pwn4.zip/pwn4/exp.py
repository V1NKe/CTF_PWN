from pwn import *

p = process('./speedrun-004')
context.log_level = 'debug'

p.recvuntil('do you have to say?\n')
gdb.attach(p)
p.send('A'*20)

p.interactive()
